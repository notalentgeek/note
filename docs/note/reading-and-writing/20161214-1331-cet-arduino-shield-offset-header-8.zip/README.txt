                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1920037
Arduino Offset Header Jig by rssalerno is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

If you've ever made a custom Arduino shield using standard perfboard, you know the two digital IO headers are separated by a non-standard distance and won't line up.  

I tried using needle nose pliers to bend the pins to match and failed miserably, so I created this thing.  It's a pair of jigs for bending an 8 pin header the precise amount needed to mate any perfboard with your Arduino.

Use the first jig to bend all 8 pins at an angle, then use the second jig to straighten the ends.  Voila!

In the original version, the first jig worked perfectly as the bending force is primarily against the header body, but the second jig needed improvement because the tiny bit of material between pins would break when attempting the bend.  This is solved in the latest release which uses metal inserts made from... a set of header pins.

To make the second jig, gently tap an 8 pin header into the 8 holes as shown in the last picture and clip off the excess with flush cutters.






# Print Settings

Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 50%-100%

Notes: 
Printed in ABS using a 0.2mm nozzle.