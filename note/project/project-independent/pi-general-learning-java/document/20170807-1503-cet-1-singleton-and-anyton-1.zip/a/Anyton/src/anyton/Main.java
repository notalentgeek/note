package anyton;

public class Main {
	public static void main (String args[]) {
		Anyton a1 = Anyton.getAnyton();
		Anyton a2 = Anyton.getAnyton();
		Anyton a3 = Anyton.getAnyton();
		Anyton a4 = Anyton.getAnyton();
		Anyton a5 = Anyton.getAnyton();
		Anyton a6 = Anyton.getAnyton(); // This must be the same with `a5`.
		
		// Test!
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		System.out.println(a4);
		System.out.println(a5);
		System.out.println(a6);
		System.out.println(a5 == a6); // This should return `true`.
	}
}