package anyton;

public class Anyton {
	// For this test, I tried to create 5 anytons.
	private static int initCount = 5;
	private static Anyton[] anyton = new Anyton[initCount];
	
	private Anyton () {}
	
	public static Anyton getAnyton () {
		for (int i = 0; i < initCount; i ++) {
			if (anyton[i] == null) {
				anyton[i] = new Anyton();
				return anyton[i];
			}
		}
		
		return anyton[initCount - 1];
	}
}