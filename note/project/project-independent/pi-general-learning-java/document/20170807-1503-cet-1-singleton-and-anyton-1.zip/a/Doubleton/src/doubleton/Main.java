package doubleton;

public class Main {
	public static void main (String args[]) {
		// Create `Doubleton` via public function `getDoubleton()`.
		Doubleton d1 = Doubleton.getDoubleton();
		Doubleton d2 = Doubleton.getDoubleton();
		// Should have the same hash code as `d2`.
		Doubleton d3 = Doubleton.getDoubleton();
		System.out.println(d1.hashCode());
		System.out.println(d2.hashCode());
		System.out.println(d3.hashCode());
	}
}