package doubleton;

class Doubleton {
    private static int initMax = 2;
    private static Doubleton doubleton[] = new Doubleton[initMax];

    // Private constructor, so the class cannot be created from outside the
    // class itself.
    private Doubleton () {}

    public static Doubleton getDoubleton () {
        if (doubleton[0] == null) {
            doubleton[0] = new Doubleton();
            return doubleton[0];
        }
        else if (doubleton[1] == null) {
            doubleton[1] = new Doubleton();
            return doubleton[1];
        }
        else {
            return doubleton[doubleton.length - 1];
        }
    }
}