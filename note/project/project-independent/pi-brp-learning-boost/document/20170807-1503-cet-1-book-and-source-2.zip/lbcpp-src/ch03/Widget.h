#ifndef WIDGET_H
#define WIDGET_H

class Widget
{
public:
  Widget() {}

  void display() {}
  void setProperties(...) {}
};

#endif /* WIDGET_H */
