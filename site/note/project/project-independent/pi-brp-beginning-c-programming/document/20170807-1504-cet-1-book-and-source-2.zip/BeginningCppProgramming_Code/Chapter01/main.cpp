#include "utils.h"
#include "name.h"
#include "time.h"

int main()
{
   PrintName();
   PrintTime();
   return 0;
}