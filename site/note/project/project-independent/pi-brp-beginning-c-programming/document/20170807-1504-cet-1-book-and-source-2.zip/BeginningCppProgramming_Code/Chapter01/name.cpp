#include "utils.h"
#include "name.h"

void PrintName()
{
   std::string name;
   std::cout << "Your first name?: ";
   std::cin >> name;
   std::cout << name;
}